package com.najjar.convertertemprature;

import org.junit.Test;

import static org.junit.Assert.assertEquals;



public class ConverterUtilTest {
    public void testConvertFahrenheitToCelsius() {
        float actual = ConverterUtil.convertFahtToCel(100);
        // expected value is 212
        float expected = 212;

        assertEquals("Conversion from celsius to fahrenheit failed", expected, actual, 0.001);
    }

    @Test
    public void testConvertCelsiusToFahrenheit() {
        float actual = ConverterUtil.convertCelToFah(212);
        // expected value is 100
        float expected = 100;

        assertEquals("Conversion from celsius to fahrenheit failed", expected, actual, 0.001);
    }
}

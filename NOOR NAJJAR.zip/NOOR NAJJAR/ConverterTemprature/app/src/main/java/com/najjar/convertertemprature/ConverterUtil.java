package com.najjar.convertertemprature;

/**
 * Created by Dell on 23/06/2017.
 */

public class ConverterUtil {
    public static float convertFahtToCel(float fahrenheit) {
        return ((fahrenheit - 32) * 5 / 9);
    }

    // converts to fahrenheit
    public static float convertCelToFah(float celsius) {
        return ((celsius * 9) / 5) + 32;
    }

}
